package com.eventapp.eventapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventappApplicationTests {

	@Test
	void contextLoads() {
	}

}
